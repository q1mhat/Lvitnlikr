package com.example.liveliker

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Color
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.random.Random

class AutoTapService : AccessibilityService() {

    companion object { var instance: AutoTapService? = null }

    private lateinit var wm: WindowManager
    private val handler = Handler(Looper.getMainLooper())
    private var panel: LinearLayout? = null
    private var target: View? = null
    private lateinit var targetLp: WindowManager.LayoutParams
    private lateinit var toggleBtn: Button
    private lateinit var label: TextView

    private var running = false
    private var intervalMs = 500L
    private val targetSize get() = (56 * resources.displayMetrics.density).toInt()

    private val tapRunnable = object : Runnable {
        override fun run() {
            if (!running) return
            val half = targetSize / 2f
            val x = targetLp.x + half + Random.nextInt(-6, 7)
            val y = targetLp.y + half + Random.nextInt(-6, 7)
            val path = Path().apply { moveTo(x, y) }
            val stroke = GestureDescription.StrokeDescription(path, 0, 40)
            dispatchGesture(GestureDescription.Builder().addStroke(stroke).build(), null, null)
            val jitter = (intervalMs * Random.nextDouble(0.85, 1.15)).toLong()
            handler.postDelayed(this, jitter)
        }
    }

    override fun onServiceConnected() {
        instance = this
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        showOverlay()
    }

    fun showOverlay() {
        if (panel != null) return
        buildTarget()
        buildPanel()
    }

    private fun hideOverlay() {
        stopTapping()
        panel?.let { wm.removeView(it) }
        target?.let { wm.removeView(it) }
        panel = null; target = null
    }

    private fun overlayParams(w: Int, h: Int, touchable: Boolean = true) =
        WindowManager.LayoutParams(
            w, h,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                (if (touchable) 0 else WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE),
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START }

    private fun buildTarget() {
        val v = View(this).apply {
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.argb(140, 255, 40, 80))
                setStroke(4, Color.WHITE)
            }
        }
        targetLp = overlayParams(targetSize, targetSize).apply {
            x = resources.displayMetrics.widthPixels / 2 - targetSize / 2
            y = resources.displayMetrics.heightPixels / 2
        }
        v.setOnTouchListener { _, e ->
            if (!running && e.action == MotionEvent.ACTION_MOVE) {
                targetLp.x = (e.rawX - targetSize / 2).toInt()
                targetLp.y = (e.rawY - targetSize / 2).toInt()
                wm.updateViewLayout(v, targetLp)
            }
            true
        }
        wm.addView(v, targetLp)
        target = v
    }

    private fun buildPanel() {
        val d = resources.displayMetrics.density
        val p = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding((8 * d).toInt(), (4 * d).toInt(), (8 * d).toInt(), (4 * d).toInt())
            background = GradientDrawable().apply {
                cornerRadius = 28 * d
                setColor(Color.argb(210, 20, 20, 20))
            }
        }
        fun btn(t: String, onClick: () -> Unit) = Button(this).apply {
            text = t; setTextColor(Color.WHITE); setBackgroundColor(Color.TRANSPARENT)
            minWidth = 0; minimumWidth = 0
            setOnClickListener { onClick() }
        }
        toggleBtn = btn("▶") { if (running) stopTapping() else startTapping() }
        label = TextView(this).apply { setTextColor(Color.WHITE); updateLabel() }
        p.addView(toggleBtn)
        p.addView(btn("−") { intervalMs = (intervalMs + 100).coerceAtMost(3000); updateLabel() })
        p.addView(label)
        p.addView(btn("+") { intervalMs = (intervalMs - 100).coerceAtLeast(200); updateLabel() })
        p.addView(btn("✕") { hideOverlay() })

        val lp = overlayParams(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT)
            .apply { gravity = Gravity.TOP or Gravity.END; y = (160 * d).toInt() }
        wm.addView(p, lp)
        panel = p
    }

    private fun updateLabel() { label.text = " ${intervalMs}ms " }

    private fun startTapping() {
        running = true
        toggleBtn.text = "⏸"
        targetLp.flags = targetLp.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        target?.let { wm.updateViewLayout(it, targetLp) }
        handler.post(tapRunnable)
    }

    private fun stopTapping() {
        running = false
        handler.removeCallbacks(tapRunnable)
        if (panel != null) toggleBtn.text = "▶"
        target?.let {
            targetLp.flags = targetLp.flags and WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE.inv()
            wm.updateViewLayout(it, targetLp)
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() { stopTapping() }
    override fun onDestroy() { hideOverlay(); instance = null; super.onDestroy() }
}
