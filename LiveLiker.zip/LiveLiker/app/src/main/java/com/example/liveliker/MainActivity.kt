package com.example.liveliker

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (24 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(pad, pad * 2, pad, pad)
        }
        root.addView(TextView(this).apply {
            text = "طريقة الاستخدام:\n\n" +
                "1) اضغط الزر الأول وفعّل خدمة «لايكات البث» من إعدادات إمكانية الوصول.\n" +
                "2) افتح بث تيك توك.\n" +
                "3) اسحب الدائرة الحمراء إلى المكان الذي تريد النقر عليه (زر القلب أو منتصف الشاشة).\n" +
                "4) اضغط ▶ للبدء و ⏸ للإيقاف. أزرار + و − تتحكم بالسرعة."
            textSize = 16f
            setTextColor(Color.DKGRAY)
            textDirection = TextView.TEXT_DIRECTION_RTL
        })
        root.addView(Button(this).apply {
            text = "١) فتح إعدادات إمكانية الوصول"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        })
        root.addView(Button(this).apply {
            text = "إظهار أزرار التحكم"
            setOnClickListener { AutoTapService.instance?.showOverlay() }
        })
        setContentView(root)
    }
}
